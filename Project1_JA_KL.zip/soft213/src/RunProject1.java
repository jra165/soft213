/**
The RunProject1 class is driver class to run Project 1.
@author Joshua Atienza, Kyle Lee
*/

public class RunProject1 {

	public static void main(String[] args) {
		
		new Shopping().run();

	}

}
