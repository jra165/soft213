/**
The RunProject1 class is driver class to run Project 1.
@author Joshua Atienza, Kyle Lee
*/

public class RunProject1 {
	
	/**
	Runs the Shopping class.
	@param args Arguments passed by command line
	*/
	public static void main(String[] args) {
		
		new Shopping().run();

	}

}
